The default league folders should be extracted to the C:\Users\Public\Documents\GDS\Fast Break College Basketball 2010\defaultleagues directory.

To use these leaguefiles in the game, select the "League File" dropdown and choose.

The logopack should be extracted to the C:\Program Files (x86)\GDS\Fast Break College Basketball 2010\images directory. Consider preserving your default "logos" folder before extracting this logopack.